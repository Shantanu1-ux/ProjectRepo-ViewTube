﻿using Models;
using System.Collections.Generic;

namespace Repository
{
    public interface IFavouriteRepo
    {
        Favourite AddFavourite(Favourite fav);
        List<Favourite> GetFavourites(string id);
        string DeleteFavourite(string id, string vid);
    }
}