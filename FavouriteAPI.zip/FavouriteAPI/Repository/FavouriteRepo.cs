﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;

namespace Repository
{
    public class FavouriteRepo : IFavouriteRepo
    { 
        private readonly FavouriteDbContext _context;
        public FavouriteRepo(FavouriteDbContext context)
        {
            _context = context;
        }
        public Favourite AddFavourite(Favourite fav)
        {
            _context.Favourites.Add(fav);
            _context.SaveChanges();
            return fav;
        }
        public List<Favourite> GetFavourites(string id)
        {
            List<Favourite> favs = new List<Favourite>();
            favs = _context.Favourites.Where(t => t.userId == id).ToList();
            return favs;
        }
        public string DeleteFavourite(string id,string vid)
        {
            //List<Favourite> favs = new List<Favourite>();
            //var favs = _context.Favourites.Where(t => t.userId == fav.userId && t.videoId==fav.videoId).ToList();
            //_context.Favourites.Remove(favs);
            //_context.SaveChanges();
            var x = (from y in _context.Favourites
                     where y.userId == id && y.videoId==vid
                     select y).FirstOrDefault();
            _context.Remove(x);
            _context.SaveChanges();
            return "favourite Added!!";
        }
    }

}
