﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using Services;

namespace FavouriteAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FavouriteController : ControllerBase
    {
        private readonly IFavouriteService _service;
        public FavouriteController(IFavouriteService service)
        {
            _service = service;
        }
        [EnableCors("Policy1")]
        [HttpGet("{id}")]
        public List<Favourite> GetFavourites(string id)
        {
            return _service.GetFav(id);
        }
        [EnableCors("Policy2")]
        [HttpPost]
        [Route("Add")]
        public IActionResult AddFavourite([FromBody] Favourite fav)
        {
            _service.AddFavourite(fav);
            return StatusCode(201, "favourite Added!!");
        }
        [EnableCors("Policy3")]
        [HttpDelete("{id}/{vid}")]
        public IActionResult Delete(string id,string vid)
        {
            _service.DeleteFavourite(id,vid);
            return StatusCode(201, "favourite deleted!!");
        }
    }
}
