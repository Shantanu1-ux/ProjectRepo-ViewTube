﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class FavouriteDbContext:DbContext
    {
        public FavouriteDbContext() { }
        public FavouriteDbContext(DbContextOptions options) : base(options) { this.Database.EnsureCreated(); }
        public DbSet<Favourite> Favourites { get; set; }
    }
}
