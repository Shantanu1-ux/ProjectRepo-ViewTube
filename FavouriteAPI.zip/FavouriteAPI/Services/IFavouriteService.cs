﻿using Models;
using System.Collections.Generic;

namespace Services
{
    public interface IFavouriteService
    {
        Favourite AddFavourite(Favourite fav);
        List<Favourite> GetFav(string id);
        string DeleteFavourite(string id, string vid);

    }
}