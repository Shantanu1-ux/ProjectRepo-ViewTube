﻿using Models;
using Repository;
using System;
using System.Collections.Generic;

namespace Services
{
    public class FavouriteService : IFavouriteService
    {
        private readonly IFavouriteRepo _repo;
        public FavouriteService(IFavouriteRepo repo)
        {
            _repo = repo;
        }
        public Favourite AddFavourite(Favourite fav)
        {
            return _repo.AddFavourite(fav);
        }

        public List<Favourite> GetFav(string id)
        {
            return _repo.GetFavourites(id);
        }

        public string DeleteFavourite(string id,string vid)
        {
           return _repo.DeleteFavourite(id,vid);
        }
    }
}
