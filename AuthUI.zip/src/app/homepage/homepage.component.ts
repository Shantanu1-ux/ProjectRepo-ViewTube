import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Favourite } from '../Model/Favourite';
//import { LoginComponent } from '../login/login.component';
import { User } from '../Model/User';
import { AuthService } from '../service/auth.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  @ViewChild('vidid') vidId: ElementRef;
  vidid:string;
  vid:string;
  favs: any[];
  constructor(private _authService:AuthService,private spinner: NgxSpinnerService) { }
  videos: any[];
  fav:Favourite;
  ngOnInit(): void {
    this.spinner.show()
      setTimeout(()=>
      {
      this.spinner.hide()
      },3000)
      this.videos = [];
      this._authService.GetVideos().subscribe(lista => {
        for (let element of lista["items"]) {
        this.videos.push(element)
        }
      });
  }
check()
{
  var tok=localStorage.getItem('token');
  if(tok!=null)
  return true;
  else
  return false;
}
add(id)
{
  this.fav=new Favourite();
  localStorage.setItem('vid',id);
  var vid=localStorage.getItem('vid');
  this.fav.userid=localStorage.getItem('currentUser')
  this.fav.videoId=vid;
  console.log(this.fav);
  this._authService.PutFavourites(this.fav).subscribe(data =>{console.log(data.userid);console.log(data.videoId)},
    error=>{console.log(error);});
    localStorage.removeItem('vid');
}
}
