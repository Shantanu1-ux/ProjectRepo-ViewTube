export class LogIn {
    userid?: string;
    password?: string;
}