export class Favourite {
    userid?: string;
    videoId?: any;
}