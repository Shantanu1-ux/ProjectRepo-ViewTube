import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Favourite } from '../Model/Favourite';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  videos: any[];
  fav:Favourite;

  constructor(private _authService:AuthService,private spinner:NgxSpinnerService) { }
categories:any[];
  ngOnInit(): void {
    this.categories = [];
    this._authService.getCategoryId().subscribe(lista=>{
      for (let element of lista["items"]) {
        this.categories.push(element);
        console.log(element);
      }
    });
  }
    getVideos(value){
      this.videos=[];
      var value;
      this._authService.getCategorySearchVideos(value).subscribe(lista=>{
        for (let element of lista["items"]) {
          this.videos.push(element);
        }
      });
    }
    addToFavourite(){
      if (this._authService.loggedIn()) {
        
      }
      else{
        alert("You need to login first");
      }
    }
AddToFavourite(id)
{
  this.fav=new Favourite();
  localStorage.setItem('vid',id);
  var vid=localStorage.getItem('vid');
  console.log(vid);
  this.fav.userid=localStorage.getItem('currentUser')
  this.fav.videoId=vid;
  console.log(this.fav);
  this._authService.PutFavourites(this.fav).subscribe(data =>{console.log(data.userid);console.log(data.videoId)},
    error=>{console.log(error);});
    localStorage.removeItem('vid');  
}

}
