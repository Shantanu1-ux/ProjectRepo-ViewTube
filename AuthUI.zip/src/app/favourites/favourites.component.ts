import { Component, OnInit } from '@angular/core';
import { YouTubePlayerModule } from '@angular/youtube-player';
import { Favourite } from '../Model/Favourite';
//import { YouTubePlayerModule } from '@angular/youtube-player';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {
  
  favs:Array<Favourite>[];
  constructor(private _authService:AuthService) { }

  ngOnInit(): void {
    var uid=localStorage.getItem('currentUser');
    this._authService.GetFavourites(uid).subscribe(data=>{this.favs=data});;
}
Remove(id)
{
  var uid =localStorage.getItem('currentUser');
  var vid=id;
  this._authService.DeleteFavourite(uid,vid).subscribe(
    data=>{},
    error=>{}
  );
}
}
